/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part1;

/**
 *
 * @author rajpreetkaur
 */
public class Rkaur70Part1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        artObject art = new artObject();
        art.setTitle("Bing Bong");// print details using mutator method
        art.setArtist("John Morten");
        art.setyearCreated(2018);
        art.setdescription("amazing");
        art.printDetails();
    }
    
}