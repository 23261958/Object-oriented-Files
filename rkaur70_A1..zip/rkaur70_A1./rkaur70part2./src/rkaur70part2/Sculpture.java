/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part2;

/**
 *
 * @author rajpreetkaur
 */
public class Sculpture extends artObject{
    private int height;
    private int weight;

    public Sculpture()
    {
        height = 0;
        weight =0;
    }
    
    public Sculpture(String title, String artist, int
            yearCreated, String description,int height, int weight) {
        super(title, artist,yearCreated,description);
        this.height = height;
        this.weight = weight;
    }

    
    public int getHeight() {
        return height;
    }

    public int getWeight() {
        return weight;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
    @Override
    public void printDetails(){
        super.printDetails();
       System.out.println("Height is "+ height + " and weight is "+  weight);
    }
   
    
}
    



