/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part2;

import java.util.ArrayList;
import java.util.Iterator;


/**
 *
 * @author rajpreetkaur
 */
public class Rkaur70part2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Sculpture> sculp = new ArrayList<>();
        //sculpture list
        sculp.add(new Sculpture("Ting tong","John Best",2020,"Wonderful",20,30));
        sculp.add(new Sculpture("Jakes","Sim Best",2019,"Amazing",10,30));
        
        // Using iterator
        Iterator<Sculpture>iter = sculp.iterator();
        while(iter.hasNext())
            iter.next().printDetails();
        //check if arraylist contain sculpture
        Sculpture scu = new Sculpture("Ting tong","John Best",2020,"Wonderful",20,30);
         System.out.println("Check if  sculpture object are in arrayList " +
          sculp.contains(scu));
        
        // get a sculpture 
        Sculpture sculpture = sculp.get(0);
        // remove method 
        Sculpture remove  = sculp.remove(0);
       
        // delete all
        System.out.println("After clearing........");
        sculp.clear();
       
        //size of Arraylist
        System.out.println("The current size of arrayList is "+ sculp.size());
        
        artObject art = new artObject("Jakes Ditch", "Samblo", 2015,"Interesting");
        System.out.println("Artist name of ArtObject");
        displayName(art);
        
        System.out.println("Artist name of Sculpture");
        displayName(sculpture);
    }
        public static void displayName (artObject A){
            System.out.println(A.getTitle());
        }
    
    
    
    
    }
    
    

       
       
       
       
        
        
        