/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part2;


/**
 *
 * @author rajpreetkaur
 */
public   class artObject {

    private String title;
    private String artist;
    private int yearCreated;
    private String description;

    public artObject() {

    }

    
    public artObject(String title, String artist, int
            yearCreated, String description) {
        this.title = title;
        this.artist = artist;
        this.yearCreated = yearCreated;
        this.description = description;
    }

    public String getTitle() { // Accesssor method
        return title;
    }

    public void setTitle(String title) { //mutator method
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public int getyearCreated() {
        return yearCreated;
    }

    public void setyearCreated(int yearCreated) {
        this.yearCreated = yearCreated;
    }

    public String getdescription() {
        return this.description;
    }

    public void setdescription(String description) {
        this.description = description;
    }

   public  void printDetails() { // print details 
        System.out.println("The title is " + getTitle() + ", Artist is " + 
        this.artist + ".It is created in " + getyearCreated() + " It is " + 
        getdescription());
    }

}

