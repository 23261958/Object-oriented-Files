/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part4;

import java.util.*;
/**
 *
 * @author rajpreetkaur
 */
public class Rkaur70part4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Stack<Sculpture> sculp = new Stack <>();
       sculp.push(new Sculpture (20,30));
       sculp.push(new Sculpture (40,20));
       sculp.push(new Sculpture (60,70));
        
       System.out.println("The sculpture is: " + sculp);
        System.out.println(sculp.peek());
        
         System.out.println("Check if sculpture i empty" + sculp.empty());
         
         sculp.pop();
         System.out.println(sculp.pop());
        
    }
    
}
