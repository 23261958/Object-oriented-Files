/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part4;

/**
 *
 * @author rajpreetkaur
 */
public interface artObject {
      String title(); // abstract methods
      String  artist();
      int yearCreated();
     String description();

}
