/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part4;

/**
 *
 * @author rajpreetkaur
 */
public class Sculpture implements artObject{
    private final  int height;
    private final  int weight;
    
    public Sculpture(int h,int w )
    {
       height = h;
       weight = w;
      }

    
     public String printDetails() {
        return height + " and  " + weight; 
    }
    
    @Override
    public String title() { // abstract method from artObject defined here 
       return "Jaxes ";     //using override
    }

    @Override
    public String artist() {
        return "john";
    }

    @Override
    public int yearCreated() {
        return 2020;
    }
    

    @Override
    public String description() { 
        return "This is amazing";
    }

}