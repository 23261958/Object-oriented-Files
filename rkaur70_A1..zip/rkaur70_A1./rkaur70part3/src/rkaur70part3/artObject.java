/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part3;

/**
 *
 * @author rajpreetkaur
 */
public  abstract class artObject {
    private String title;
    private String artist;
    private int yearCreated;
    private String description;

    public artObject() { // default construtor 

    }
    
    public artObject(String title, String artist, int
            yearCreated, String description) {
        this.title = title;
        this.artist = artist;
        this.yearCreated = yearCreated;
        this.description = description;
    }
   
   public  void printDetails() { // print method 
        System.out.println("The title is " + title + ", Artist is " + 
        this.artist + ".It is created in " + yearCreated + " It is " + 
        description );
    }
   
   public abstract String authorName(); //abstract method without body 
   
       
   }

   


