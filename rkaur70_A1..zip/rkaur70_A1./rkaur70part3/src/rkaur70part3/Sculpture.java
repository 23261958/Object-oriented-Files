/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part3;


public class Sculpture extends artObject{
     private final int height;
    private  final  int weight;

    public Sculpture()
    {
        super();
        height = 0;
        weight =0;
    }
     
    public Sculpture(String title, String artist, int
            yearCreated, String description,int height, int weight) {
        super(title, artist, yearCreated, description);
        this.height = height;
        this.weight = weight;
    }
    
    @Override
    public void printDetails(){
        super.printDetails();
       System.out.println("Height is "+ height + " and weight is "+  weight);
    }

    @Override
    public String authorName() {// abstract method from artObject defined here 
        return "harry";          //using overiding 
    }

   
    
}
    




