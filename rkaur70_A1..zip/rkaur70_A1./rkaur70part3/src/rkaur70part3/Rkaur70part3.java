/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part3;

/**
 *
 * @author rajpreetkaur
 */
public class Rkaur70part3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Sculpture scul = new Sculpture();
        
        System.out.println(scul.authorName()); // print abstract method
       


    }
    
}
