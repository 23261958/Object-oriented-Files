/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part1;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.*;
import javafx.scene.paint.Color;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author Rajpreet
 */
public class Rkaur70part1 extends Application {

    @Override
    public void start(Stage primaryStage) {
        Circle shapeA = new Circle();
        shapeA.setCenterX(50);
        shapeA.setCenterY(50);
        shapeA.setRadius(15);
        shapeA.setStroke(Color.PURPLE);
        shapeA.setFill(Color.BROWN);
        shapeA.setOnKeyPressed(new EventHandler<KeyEvent>() {//key event
            //using keypressed
            @Override
            public void handle(KeyEvent event) {
                System.out.println("Character:" + event.getCharacter());
            }
        });
        shapeA.setOnMouseEntered(new EventHandler<MouseEvent>() {
//MpouseEntered mouse event
            public void handle(MouseEvent me) {
                System.out.println("X:" + me.getX() + "Y:" + me.getY());
            }  //USING MOUSEEVENT WILL CHANGE X AND Y OF THE CIRCLE
        });

        Rectangle shapeB = new Rectangle(50, 25, 25, 50);
        shapeB.setStroke(Color.CHOCOLATE);
        shapeB.setFill(Color.BLUE);
        shapeB.setOnKeyTyped(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                System.out.println("text:" + event.getText());
            }
        });

        shapeB.addEventHandler(MouseEvent.MOUSE_PRESSED, (MouseEvent M) -> {
            System.out.println("right");
            shapeB.setFill(Color.PINK);
        });

        Line shapeC = new Line(100, 20, 300, 40);
        shapeC.setStroke(Color.DEEPPINK);
        shapeC.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent M) {
                System.out.println("LEFT");
            }
        });

        Ellipse shapeD = new Ellipse(120, 170, 40, 20);
        shapeD.setStroke(Color.PURPLE);
        shapeD.setFill(Color.GOLD);
        shapeD.setOnMouseExited(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent me) {
                System.out.println("Mouse Exited");
                shapeD.setFill(Color.CHOCOLATE);
            }
        });

        GridPane pane = new GridPane();//using gridpane 
        pane.add(shapeA, 10, 10);// setting the pane for every shape
        pane.add(shapeB, 20, 20);
        pane.add(shapeC, 15, 20);
        pane.add(shapeD, 30, 40);
        pane.setHgap(7);
        pane.setVgap(12);
        GridPane.setHalignment(shapeA, HPos.LEFT);
        GridPane.setValignment(shapeA, VPos.TOP);

        Scene scene = new Scene(pane, 600, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Hello everyone");
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
