/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part3;

import java.util.HashSet;

/**
 *
 * @author Simi
 */
class Sculpture {

    // text field
    private String title;
    // text field
    private String artist;
    // slider
    private Integer yearCreated;
    // radio field
    private String height;
    // combo box
    private String weight;

// list view
    private HashSet<String> countryOfOrigin = new HashSet(); // check boxes

    private HashSet<String> material = new HashSet();

    public Sculpture() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;

    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;

    }

    public Integer getYearCreated() {
        return yearCreated;
    }

    public void setYearCreated(Integer yearCreated) {
        this.yearCreated = yearCreated;

    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;

    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;

    }

    public HashSet<String> getCountryOfOrigin() {
        return countryOfOrigin;

    }

    public void setCountryOfOrigin(HashSet<String> countryOfOrigin) {
        this.countryOfOrigin = countryOfOrigin;

    }

    public HashSet<String> getMaterial() {
        return material;
    }

    public void setMaterial(HashSet<String> material) {
        this.material = material;

    }
}
