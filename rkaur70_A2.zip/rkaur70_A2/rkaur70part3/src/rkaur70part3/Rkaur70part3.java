/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part3;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import java.util.HashSet;
import java.util.LinkedList;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.GridPane;

/**
 *
 * @author Rajpreet
 */
public class Rkaur70part3 extends Application {

    TextField titleSculpture = new TextField(); //field for Sculpture title
    Label labelTitle = new Label("Title");//title label

    Label labelartist = new Label("Artist"); //field for Sculpture artist
    TextField artistText = new TextField();// title label

    Slider slider = new Slider();

    Label labelheight = new Label("height");//height label

    Label yearlabel = new Label("Year");//label for year
    Label label = new Label(" ");

    ToggleGroup groupHeight = new ToggleGroup();//togle group for radiobuttons
    RadioButton r1 = new RadioButton("tall(over 5m)");
    RadioButton r2 = new RadioButton("medium(shorter than 5 m,taller than 1m)");
    RadioButton r3 = new RadioButton("short(under 1m)");

    Label material = new Label("Materials");//Label for materials
    CheckBox Stone = new CheckBox("Stone)");
    CheckBox Metal = new CheckBox("Metal)");
    CheckBox glass = new CheckBox("glass)");
    CheckBox pottery = new CheckBox("Pottery)");

    Label countrylabel = new Label("Country");//Label for Country
    Label weight = new Label("Weight");//label for weight
    ChoiceBox weightchoiceBox = new ChoiceBox();//choicebox for sculpture weight

    //Listview for countries
    ObservableList<String> Countries = FXCollections.observableArrayList(
            "Italy", "France", "China", "United Kingdom");
    ListView<String> countriesListView = new ListView<String>(Countries);

    Button button1 = new Button("Add Sculpture");//bttton to add sculpture
    Button button2 = new Button("new Sculpture");//button for new sculpture

    GridPane gridPane = new GridPane();
    //linked list to store sculpture
    LinkedList<Sculpture> Sculpture = new LinkedList<Sculpture>();

    @Override
    public void start(Stage stage) {

        // item added to choicebox
        weightchoiceBox.getItems().add("Very Heavy");
        weightchoiceBox.getItems().add("Heavy");
        weightchoiceBox.getItems().add("Medium");
        weightchoiceBox.getItems().add("Light");
        weightchoiceBox.getItems().add("Very Light");

        r1.setToggleGroup(groupHeight);// radio buttons added
        r2.setToggleGroup(groupHeight);
        r3.setToggleGroup(groupHeight);

        slider.setMin((int) 1900);//slider for year
        slider.setMax((int) 2020);
        slider.setValue(0);
        slider.setShowTickLabels(false);
        slider.valueProperty().addListener(
                new ChangeListener<Number>() {

            @Override
            public void changed(ObservableValue<? extends Number> 
                    observable, Number oldValue, Number newValue) {

                label.setText("" + newValue.intValue());
            }
        });

        button1.setOnAction(new EventHandler() {

            @Override
            public void handle(Event e) {
                //FORM DETAILS
                String Title = titleSculpture.getText();
                String Artist = artistText.getText();
                Integer yearCreated = Integer.parseInt(label.getText().toString());
                String height;
                if (r1.isSelected() == true) {
                    height = "Tall";
                } else if (r2.isSelected() == true) {
                    height = "Medium";
                } else {
                    height = "Small";
                }
                String weight = weightchoiceBox.getSelectionModel().
                        getSelectedItem().toString();
                HashSet<String> country = new HashSet<String>();
                country.add(countriesListView.getSelectionModel().getSelectedItem());
                HashSet<String> material = new HashSet<String>();
                if (Stone.isSelected() == true) {
                    material.add("Stone");
                }
                if (glass.isSelected() == true) {
                    material.add("Pottery");
                }
                if (pottery.isSelected() == true) {
                    material.add("Wood Carving");
                }
                if (Metal.isSelected() == true) {
                    material.add("Metal");
                }
                // addObject details
                addObject(Title, Artist, yearCreated, height, weight, country, material);
            }
        });

        button2.setOnAction(new EventHandler() {

            @Override
            public void handle(Event t) {

                clear();//button2 clear details
            }
        });

        gridPane.setMinSize(600, 500);
        gridPane.setPadding(new Insets(20, 20, 10, 10));
        gridPane.setAlignment(Pos.CENTER);
        gridPane.add(titleSculpture, 1, 0);
        gridPane.add(labelTitle, 0, 0);
        gridPane.add(labelartist, 0, 1);
        gridPane.add(artistText, 1, 1);
        gridPane.add(yearlabel, 0, 2);
        gridPane.add(slider, 1, 2);
        gridPane.add(label, 2, 2);
        gridPane.add(labelheight, 0, 3);
        gridPane.add(r1, 1, 3);
        gridPane.add(r2, 2, 3);
        gridPane.add(r3, 1, 4);
        gridPane.add(material, 0, 5);
        gridPane.add(Stone, 1, 5);
        gridPane.add(glass, 2, 5);
        gridPane.add(pottery, 1, 6);
        gridPane.add(Metal, 2, 6);
        gridPane.add(countrylabel, 0, 8);
        gridPane.add(countriesListView, 1, 8);
        gridPane.add(weight, 0, 9);
        gridPane.add(weightchoiceBox, 1, 9);
        gridPane.add(button1, 0, 11);
        gridPane.add(button2, 0, 12);
        Scene scene = new Scene(gridPane);
        stage.setTitle("Sculpture Form");
        stage.setScene(scene);
        stage.show();

    }

    public void addObject(String title, String artist, Integer yearCreated,
            String height, String weight, HashSet<String> country, HashSet<String> material) {
        //create  addobject method
        Sculpture s = new Sculpture();
        s.setTitle(title);
        s.setArtist(artist);
        s.setYearCreated(yearCreated);
        s.setHeight(height);
        s.setWeight(weight);
        s.setCountryOfOrigin(country);
        s.setMaterial(material);
        Sculpture.add(s);
    }

    public void clear() {
        //clear all fields
        labelTitle.setText("");
        artistText.setText("");
        slider.setValue(0);
        groupHeight.selectToggle(null);
        weightchoiceBox.setValue(null);
        countriesListView.getSelectionModel().clearSelection();
        Stone.setSelected(false);
        Metal.setSelected(false);
        glass.setSelected(false);
        pottery.setSelected(false);
    }

//
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
