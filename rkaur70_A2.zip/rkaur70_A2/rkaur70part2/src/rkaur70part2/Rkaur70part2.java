/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaur70part2;

import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.stage.Stage;
import javafx.scene.shape.Polygon;

/**
 *
 * @author Rajpreet
 */
public class Rkaur70part2 extends Application {

    /**
     *
     * @param stage
     */
    @Override
    public void start(Stage stage) {
        pathTransition(stage);// three effects added comment out two of them when
        // fadeTransition(stage);                    // playing one of them  
        //  timeline(stage);
    }

    /**
     *
     * @param primaryStage
     */
    public void pathTransition(Stage primaryStage) {
        Pane pane = new Pane();

        Polygon polygon
                = new Polygon(
                        250.0, 25.0, 600.0, 25.0, 800.0, 150.0, 800.0, 400.0,
                        600.0, 500.0, 250.0, 500.0, 50.0, 400.0, 50.0, 150.0);// POLYGON eight sides
        polygon.setFill(Color.PINK);
        polygon.setStroke(Color.BLACK);// outline of polygon

        Ellipse ellipse = new Ellipse(10, 10, 15, 20);//Ellipse sides
        ellipse.setStroke(Color.PURPLE);
        ellipse.setFill(Color.GOLD);
        ellipse.setRotate(100);

        pane.getChildren().addAll(ellipse, polygon);//pane using 
        PathTransition pathTransition = new PathTransition();//pathtransition
        //effect used 
        pathTransition.setDuration(Duration.minutes(1));
        pathTransition.setPath(polygon);
        pathTransition.setNode(ellipse);// ellipse is node so it will rotate 
        //on path
        //setting up cycle count
        pathTransition.setCycleCount(Timeline.INDEFINITE);
        pathTransition.setInterpolator(Interpolator.LINEAR);
        pathTransition.play();
        pathTransition.setOrientation//setting orientation for path transition
                (PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pathTransition.setAutoReverse(true);//setting uto reverse to true

        Scene scene = new Scene(pane, 400, 400);
        primaryStage.setTitle("pathTransition");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void fadeTransition(Stage primaryStage) {
        Pane pane = new Pane();
        Polygon polygon
                = new Polygon(
                        250.0, 25.0, 600.0, 25.0, 800.0, 150.0, 800.0, 400.0,
                        600.0, 500.0, 250.0, 500.0, 50.0, 400.0, 50.0, 150.0);
        polygon.setFill(Color.RED);
        polygon.setStroke(Color.BLACK);

        pane.getChildren().addAll(polygon);
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setDuration(Duration.millis(10000));
        fadeTransition.setFromValue(10);
        fadeTransition.setToValue(0);
        fadeTransition.setCycleCount(Timeline.INDEFINITE);
        fadeTransition.setAutoReverse(true);
        fadeTransition.setNode(polygon);
        fadeTransition.play();//playing path transition

        Scene scene = new Scene(pane, 400, 400);
        primaryStage.setTitle("fadeTransition");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public void timeline(Stage primaryStage) {
        Pane pane = new Pane();
        Circle circle = new Circle();
        circle.setCenterX(50);
        circle.setCenterY(50);
        circle.setRadius(15);
        circle.setStroke(Color.PURPLE);
        circle.setFill(Color.BROWN);

        pane.getChildren().addAll(circle);
        // event handler use and duration is set up to 2 second
        EventHandler<ActionEvent> change = evt -> changeCircle(circle);
        Timeline myAnimation = new Timeline();
        myAnimation.getKeyFrames().add(new KeyFrame(Duration.seconds(2), change));
        myAnimation.setCycleCount(Timeline.INDEFINITE);
        myAnimation.play();
        Scene scene = new Scene(pane, 400, 400);
        primaryStage.setTitle("timeline");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void changeCircle(Circle circle) {// method to change color 
        if (circle.getFill().equals(Color.BROWN)) {
            circle.setStroke(Color.PINK);
            circle.setFill(Color.AQUA);// color will be changed to Aqua
        } else {
            circle.setStroke(Color.PURPLE);
            circle.setFill(Color.BROWN);

        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
