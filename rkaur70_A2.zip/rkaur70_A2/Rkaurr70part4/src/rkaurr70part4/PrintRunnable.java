/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaurr70part4;

/**
 *
 * @author rajpreet
 */
public class PrintRunnable implements Runnable {
       private String titles;

    public PrintRunnable(String titles) {
       this.titles = titles;
       System.out.println(titles +"started");
}
  
    @Override
    public void run(){
        for(int i=0; i<20;i++){//20 times running in consoles
            System.out.print(titles);
            try{
            Thread.sleep(100);
            }catch(InterruptedException e){
        }
    }
    }
}
    

