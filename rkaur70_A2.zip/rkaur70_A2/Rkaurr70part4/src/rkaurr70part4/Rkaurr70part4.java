/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaurr70part4;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author rajpreet
 */
public class Rkaurr70part4 {
    private String[] titles ={"Donatello's Equestrian Monument of Gattamelata",
      "The Terracotta Army","Michelangelo's David","Maman"};
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Thread created and their priorities
        Thread thread1 = new Thread("Donatello's Equestrian Monument of Gattamelata");
        thread1.setPriority(Thread.MAX_PRIORITY);
        Thread thread2 = new Thread("The Terracotta Army");
        thread2.setPriority(Thread.MIN_PRIORITY);
        Thread thread3 = new Thread("Michelangelo's David");
        thread3.setPriority(Thread.NORM_PRIORITY);
        Thread thread4 = new Thread("Maman");
        thread4.setPriority(Thread.MIN_PRIORITY);

        thread1.start();
       thread2.start();
        thread3.start();
        thread4.start();
        //fixed thread pool
      ExecutorService  pool = Executors.newFixedThreadPool(3);
      pool.execute(thread4);
      pool.execute(thread2);
      pool.execute(thread3);
      pool.execute(thread1);
      pool.shutdown();//shutdown of fixed threadpool
      if (pool.isShutdown()){
          System.out.println("pool is shutdown");
         
      }
      // chachedThreadpool
      ExecutorService  chached = Executors.newCachedThreadPool();
      chached.execute(thread4);
      chached.execute(thread2);
      chached.execute(thread3);
      chached.execute(thread1);
      chached.shutdown();// shutdown chachedThreadpool
      if(pool.isShutdown()){
          System.out.println("pool is shutdown");
      }
     
      }
}
    


