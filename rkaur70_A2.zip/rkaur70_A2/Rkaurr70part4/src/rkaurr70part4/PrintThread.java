/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rkaurr70part4;

/**
 *
 * @author rajpreet
 */
public class PrintThread extends Thread {

    private String titles;

    public PrintThread(String text) {
        this.titles = titles;
    }

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {//20 times running in console
            try {
                System.out.print(titles);
                Thread.sleep(1000);
                }catch(InterruptedException e){                       
            }
        }
    }
}
